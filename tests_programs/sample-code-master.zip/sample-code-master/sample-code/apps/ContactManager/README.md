# ContactManager

ContactManager.apk only runs with UIAutomator and not with seledroid due to absence of
INTERNET permission to use ContactManager with selendroid use ContactManger-selendroid.apk
