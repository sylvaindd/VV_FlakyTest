package com.saucelabs.appium.page_object.widgets.android.extended;

import com.saucelabs.appium.page_object.widgets.android.annotated.AnnotatedAndroidReview;
import org.openqa.selenium.WebElement;

public class ExtendedAndroidReview extends AnnotatedAndroidReview {

    protected ExtendedAndroidReview(WebElement element) {
        super(element);
    }
}
