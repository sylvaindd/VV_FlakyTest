package com.saucelabs.appium.page_object.widgets.android.extended;

import com.saucelabs.appium.page_object.widgets.android.annotated.AnnotatedAndroidMovies;
import org.openqa.selenium.WebElement;

public class ExtendedAndroidMovies extends AnnotatedAndroidMovies {

    protected ExtendedAndroidMovies(WebElement element) {
        super(element);
    }
}
