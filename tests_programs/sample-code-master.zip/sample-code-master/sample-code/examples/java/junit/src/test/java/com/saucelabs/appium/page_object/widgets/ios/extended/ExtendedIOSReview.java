package com.saucelabs.appium.page_object.widgets.ios.extended;

import com.saucelabs.appium.page_object.widgets.ios.annotated.AnnotatedIOSReview;
import org.openqa.selenium.WebElement;

public class ExtendedIOSReview extends AnnotatedIOSReview {
    protected ExtendedIOSReview(WebElement element) {
        super(element);
    }
}
