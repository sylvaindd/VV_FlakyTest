package com.saucelabs.appium.page_object.widgets;

public interface WidgetTest {

    public void checkACommonWidget();

    public void checkAnAnnotatedWidget();

    public void checkAnExtendedWidget();

    public void checkTheLocatorOverridingOnAWidget();

}
